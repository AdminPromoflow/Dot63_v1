Local source snapshot: 2026-11-10
Delivery Options configuration and preview flow.
No credentials, database dumps or third-party vendor libraries included.

Configure and save
Delivery Times HTML → delivery_times.js collects options[] → fetch POST → request_security.js adds CSRF header → controller/products/delivery.php → CatalogAccess checks supplier, CSRF and ownership → DeliverySettings::save → DeliveryOptions::normalize → PDO UPDATE → JSON response → response.json() → Saved or error message.

Load supplier preview
index.php → preview.php → SupplierPreviewApp → URLSearchParams.get("sku") → getProduct() → makeRequest() → secure fetch → controller/order/product.php → handleProduct() → getSupplierPreview() → supplier session + owned product → DeliveryOptions::catalog(product_id) → two SELECTs → fromRow() → delivery_catalog JSON → makeRequest returns payload → PreviewStore.setProduct().

Select variations and quantity
root_variation_id → loadRoot() → loadNode() → cached leaf/node or variation-children AJAX → selectedByLevel/rootVariation → renderSelectedPath() → deepest selected base-price source → PricesController.render() and select() → selectedPriceId and selectedQuantity → refreshVariationExtras() → local variationExtras() or legacy AJAX fallback → updateSummary().

Calculate and display delivery
updateSummary() → subtotal in pence → commonDelivery(catalog, selected IDs, price ID, quantity, subtotal) → collect selected variation + applicable tier options → ignore unconfigured sources → intersect days → calculate each percentage on the same subtotal and add fixed amounts once → renderDelivery() → radio options and breakdown → user change → store.selectedDelivery → updateSummary().

Load customer preview
CustomerPreviewApp uses get_customer_preview. getCustomerProduct() permits only approved products in statuses 1, 2 or 3. The customer uses the same PreviewStore, PricesController and delivery calculation; no supplier account is required for public reads.

Load Promoflow review
Promoflow preview.php includes the Dot63 supplier template. PreviewLogic extends SupplierPreviewApp with review actions and requests_63_api.php. That API checks the Promoflow session and request origin, forwards allowed fields and the session cookie using cURL to promoflow_webhook.php. The webhook requires a reviewer; Product::handleReview dispatches to the shared preview readers. JSON returns through both servers to the same JavaScript pipeline.

Current limits and behavior
Preview estimates only: delivery selection is not saved to the cart and no delivery charge is added to checkout by this feature. Selecting a delivery radio does not call the server. Without configuration the delivery fieldset is hidden. With configured sources but no common day, the page displays No common delivery option. The selected day is kept if compatible; otherwise the longest common day is selected. A zero surcharge remains a valid option. NULL delivery_options uses the old scalar fields; [] explicitly means no options. New JSON configuration synchronizes scalar fields with its first (shortest) day. Optional daily configurations do not mean automatic discounts, compounding percentages, per-unit fixed fees, business-day calendars or date calculations.

FILES
Dot63_v1/view/delivery_times/index.php
Dot63_v1/view/delivery_times/list.php
Dot63_v1/view/delivery_times/delivery_times.js
Dot63_v1/view/delivery_times/delivery_times.css
Dot63_v1/controller/products/delivery.php
Dot63_v1/controller/security/catalog_access.php
Dot63_v1/model/delivery_settings.php
Dot63_v1/model/delivery_options.php
Dot63_v1/model/delivery_price.php
Dot63_v1/controller/config/migrations/20261109_add_delivery_price.sql
Dot63_v1/controller/config/migrations/20261109_add_delivery_time_days.sql
Dot63_v1/controller/config/migrations/20261110_add_delivery_options.sql
Dot63_v1/controller/security/bootstrap.php
Dot63_v1/controller/security/csrf.php
Dot63_v1/view/global/security/page_head.php
Dot63_v1/view/global/security/request_security.js
Dot63_v1/controller/config/database.php
Dot63_v1/controller/config/database_config.php
Dot63_v1/view/preview_porduct/index.php
Dot63_v1/view/preview_porduct/preview_porduct/preview.php
Dot63_v1/view/preview_porduct/preview_porduct/preview_logic.js
Dot63_v1/view/preview_porduct/preview_porduct/preview_api.js
Dot63_v1/view/preview_porduct/preview_porduct/preview_store.js
Dot63_v1/view/preview_porduct/prices/prices.js
Dot63_v1/view/preview_porduct/variations/variations.js
Dot63_v1/controller/order/product.php
Dot63_v1/model/variations.php
Dot63_v1/model/prices.php
Dot63_v1/view/preview_product_customers/index.php
Dot63_v1/view/preview_product_customers/preview_porduct/preview.php
Dot63_v1/view/preview_product_customers/preview_porduct/preview_logic.js
Dot63_v1/view/preview_product_customers/preview_porduct/preview_api.js
Dot63_v1/view/preview_product_customers/preview_porduct/preview_store.js
Dot63_v1/view/preview_product_customers/variations/variations.js
Dot63_v1/view/preview_product_customers/prices/prices.js
Dot63_v1/view/global/quantity_selector/quantity_selector.js
Dot63_v1/view/global/quantity_selector/quantity_selector.php
Dot63_v1/view/global/delivery_options/delivery_options.php
Dot63_v1/view/global/delivery_options/common_delivery.js
Dot63_v1/view/preview_product_customers/preview_porduct/preview.css
Promoflow_v1/view/preview_porduct/index.php
Promoflow_v1/view/preview_porduct/preview_porduct/preview.php
Promoflow_v1/view/preview_porduct/preview_porduct/preview_logic.js
Promoflow_v1/controller/dot63/requests_63_api.php
Dot63_v1/controller/promoflow/promoflow_webhook.php
Dot63_v1/controller/products/price.php
Dot63_v1/controller/products/variations.php
Dot63_v1/view/variations/varia/variations.js
Dot63_v1/view/prices/prices/prices.js
Dot63_v1/tests/delivery_options.php
Dot63_v1/tests/delivery_settings.php
Dot63_v1/tests/delivery_price.php
Dot63_v1/tests/customer_delivery_summary.cjs
Dot63_v1/tests/delivery_times_edit.cjs
Dot63_v1/tests/delivery_times_tabs.cjs
Dot63_v1/tests/delivery_times_collapse.cjs
Dot63_v1/tests/preview_request_reuse.cjs