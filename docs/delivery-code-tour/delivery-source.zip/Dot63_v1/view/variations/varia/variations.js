// Variations page controller.
class Variations {
  constructor() {
    // Main form.
    this.form = document.getElementById("variationForm");

    // Decision controls.
    this.variationsNoRadio = document.getElementById("variations_no");
    this.variationsYesRadio = document.getElementById("variations_yes");
    this.noVariationsTip = document.getElementById("no_variations_tip");

    // Variation fields.
    this.parentSelect = document.getElementById("parent_variations");
    this.nameInput = document.getElementById("variation_name");
    this.typeSelect = document.getElementById("group");
    this.deliveryTimeInput = document.getElementById("delivery_time_days");
    this.deliveryPriceInput = document.getElementById("delivery_price");
    this.deliveryPriceType = document.getElementById("delivery_price_type");
    this.deliveryPriceType?.addEventListener("change", () => this.updateDeliveryUnit());
    this.namePdfInput = document.getElementById("name_pdf_artwork");

    // Image fields.
    this.imgInput = document.getElementById("variation_image");
    this.imgPreview = document.getElementById("img_preview");
    this.clearImgBtn = document.getElementById("clear_image");

    // PDF fields.
    this.pdfInput = document.getElementById("variation_pdf");
    this.pdfPreview = document.getElementById("pdf_preview");
    this.clearPdfBtn = document.getElementById("clear_pdf");

    // Variation menu.
    this.menuBtn = document.getElementById("menu_btn");
    this.menuList = document.getElementById("menu_list");

    // Buttons.
    this.addBtn = document.getElementById("add_variation");
    this.saveBtn = document.getElementById("save_variation");
    this.nextBtn = document.getElementById("next_variations");
    this.resetBtn = document.getElementById("reset_form");
    this.backBtn = document.getElementById("btn_back_variations");
    this.deleteVariationBtn = document.getElementById("delete_variation");

    // File state.
    this.attachImage = false;
    this.attachPDF = false;

    // Used to remove old image preview URLs.
    this.currentImageObjectUrl = null;
    {
      document.addEventListener("DOMContentLoaded", () => {
        if (window.headerAddProduct?.setCurrentHeader) {
          window.headerAddProduct.setCurrentHeader("variations");
        }
      });
      if (this.typeSelect) {
        this.typeSelect.innerHTML = `
        <option value="" disabled selected>
          Select a variation type
        </option>
      `;
        this.typeSelect.value = "";
      }
      {
        const noChoice = this.variationsNoRadio?.closest(".cp-choice");
        const yesChoice = this.variationsYesRadio?.closest(".cp-choice");
        const updateUi = () => {
          const isNo = Boolean(this.variationsNoRadio?.checked);
          if (this.noVariationsTip) {
            this.noVariationsTip.hidden = !isNo;
          }
          noChoice?.classList.toggle("is-selected", isNo);
          yesChoice?.classList.toggle("is-selected", !isNo);
          this.form?.classList.toggle("is-hidden", isNo);
        };
        this.variationsNoRadio?.addEventListener("change", updateUi);
        this.variationsYesRadio?.addEventListener("change", updateUi);
        updateUi();
      }
      {
        // Image preview.
        if (this.imgInput && this.imgPreview) {
          this.imgInput.addEventListener("change", () => this.handleImgInputChange());
        }

        // Remove image.
        // Remove image.
        if (this.clearImgBtn && this.imgInput && this.imgPreview) {
          this.clearImgBtn.addEventListener("click", () => this.handleClearImgBtnClick());
        }

        // PDF preview.
        // PDF preview.
        if (this.pdfInput && this.pdfPreview) {
          this.pdfInput.addEventListener("change", () => this.handlePdfInputChange());
        }

        // Remove PDF.
        // Remove PDF.
        if (this.clearPdfBtn && this.pdfInput && this.pdfPreview) {
          this.clearPdfBtn.addEventListener("click", () => this.handleClearPdfBtnClick());
        }
      }
      {
        if (!(!this.menuBtn || !this.menuList)) {
          this.menuBtn.addEventListener("click", event => this.handleMenuBtnClick(event));
          document.addEventListener("click", event => this.handleDocumentClick(event));
          document.addEventListener("keydown", event => this.handleDocumentKeydown(event));
          this.menuList.addEventListener("click", event => this.handleMenuListClick(event));
        }
      }
      {
        // Back.
        this.backBtn?.addEventListener("click", () => this.handleBackBtnClick());

        // Reset.
        // Reset.
        this.resetBtn?.addEventListener("click", event => this.handleResetBtnClick(event));

        // Save and next.
        // Save and next.
        this.nextBtn?.addEventListener("click", () => this.handleNextBtnClick());

        // Save.
        // Save.
        this.saveBtn?.addEventListener("click", () => this.handleSaveBtnClick());

        // New variation.
        // New variation.
        this.addBtn?.addEventListener("click", () => {
          this.addNewVariation();
        });

        // Delete variation.
        // Delete variation.
        this.deleteVariationBtn?.addEventListener("click", () => {
          this.deleteVariation();
        });
      }
      this.getVariationDetails();
    }
  }

  /* =========================
     Decision interface
  ========================= */

  /* =========================
     Button events
  ========================= */

  /* =========================
     Delete variation
  ========================= */

  async deleteVariation() {
    const {
      skuProduct,
      skuVariation
    } = this.readSkuParamsFromUrl();
    const payload = {
      action: "delete_variation",
      sku_variation: skuVariation
    };
    try {
      const response = await this.makeRequest("../../controller/products/variations.php", payload);
      const current = new URL(window.location.href);
      const currentSkuVariation = (current.searchParams.get("sku_variation") || "").trim();
      if (response.success) {
        alert("The variation was deleted successfully.");
        const dest = new URL("../../view/variations/index.php", window.location.href);
        dest.searchParams.set("sku", response.sku_product);
        dest.searchParams.set("sku_variation", response.sku_default_variation);
        window.location.assign(dest);
      } else {
        const defaultSku = String(response.sku_default_variation || "").trim();
        if (defaultSku === currentSkuVariation) {
          alert("The Default variation cannot be deleted.");
        } else {
          alert(response.error || "The variation could not be deleted.");
        }
      }
    } catch (error) {
      console.error("Error loading variation details:", error);
    }
  }

  /* =========================
     Variation menu
  ========================= */

  /* =========================
     File inputs
  ========================= */

  /* =========================
     Default variation
  ========================= */

  async getDefaultVariation() {
    const {
      skuProduct
    } = this.readSkuParamsFromUrl();
    try {
      const response = await this.makeRequest("../../controller/products/variations.php", {
        action: "get_sku_default_variation",
        sku: String(skuProduct).trim()
      });
      if (!response?.success) {
        console.warn("Unexpected response:", response);
        return;
      }
      const skuVariation = String(response?.sku_default_variation || "").trim();
      if (!skuVariation) {
        return;
      }
      alert("The variation details have been saved successfully.");
      window.location.href = "../../view/variations/index.php" + `?sku=${encodeURIComponent(skuProduct)}` + `&sku_variation=${encodeURIComponent(skuVariation)}`;
    } catch (error) {
      console.error("getDefaultVariation error:", error);
    }
  }

  /* =========================
     Data loading
  ========================= */

  async getVariationDetails() {
    const {
      skuProduct,
      skuVariation
    } = this.readSkuParamsFromUrl();
    const payload = {
      action: "get_variation_details",
      sku: skuProduct,
      sku_variation: skuVariation
    };
    try {
      const response = await this.makeRequest("../../controller/products/variations.php", payload);
      console.log("Response text:", response);
      if (!response?.success) {
        return;
      }
      this.renderTopMenu(response.variations, skuVariation);
      this.renderCurrentNameAndDefaultRules(response.current);
      this.renderParentSelect(response.variations, response.current, response.parent, response.product);
      this.renderTypeVariationsSelect(response.type_variations, response.current?.type_id);
      this.renderServerPreviews(response.current);
      this.attachImage = false;
      this.attachPDF = false;
    } catch (error) {
      console.error("Error loading variation details:", error);
    }
  }

  /* =========================
     Rendering
  ========================= */

  renderTopMenu(variationsRaw, skuVariation) {
    if (!this.menuList) {
      return;
    }
    this.menuList.innerHTML = "";
    const variations = Array.isArray(variationsRaw) ? variationsRaw : [];
    const levelColors = ["#0f2140", "#0b6b6b", "#7a4d0f", "#5a2d82", "#1d6b2a"];
    const selectedSku = String(skuVariation || "").trim().toUpperCase();
    const fragment = document.createDocumentFragment();
    for (let index = 0; index < variations.length; index += 1) {
      const variation = variations[index] || {};
      const name = String(variation?.name ?? "(unnamed)");
      const sku = String(variation?.SKU ?? variation?.sku ?? "");
      const level = Number(variation?.level ?? 0) || 0;
      const color = levelColors[level] || levelColors[levelColors.length - 1];
      const indentation = 28 + level * 18;
      const listItem = document.createElement("li");
      listItem.dataset.sku = sku;
      listItem.style.position = "relative";
      listItem.style.padding = "8px 10px";
      listItem.style.paddingLeft = `${indentation}px`;
      listItem.style.borderRadius = "10px";
      listItem.style.cursor = "pointer";
      listItem.style.marginBottom = "6px";
      listItem.style.borderLeft = `4px solid ${color}`;
      listItem.style.background = "rgba(255,255,255,0.03)";
      const dot = document.createElement("span");
      dot.setAttribute("aria-hidden", "true");
      dot.style.position = "absolute";
      dot.style.left = `${Math.max(8, indentation - 14)}px`;
      dot.style.top = "50%";
      dot.style.transform = "translateY(-50%)";
      dot.style.width = "8px";
      dot.style.height = "8px";
      dot.style.borderRadius = "999px";
      dot.style.background = color;
      dot.style.opacity = ".85";
      const nameElement = document.createElement("strong");
      nameElement.textContent = name;
      const hiddenSku = document.createElement("span");
      hiddenSku.textContent = sku;
      hiddenSku.style.position = "absolute";
      hiddenSku.style.left = "-9999px";
      hiddenSku.style.width = "1px";
      hiddenSku.style.height = "1px";
      hiddenSku.style.overflow = "hidden";
      listItem.appendChild(dot);
      listItem.appendChild(nameElement);
      listItem.appendChild(hiddenSku);
      const candidateSku = String(sku).trim().toUpperCase();
      if (candidateSku && candidateSku === selectedSku) {
        listItem.classList.add("is-selected");
        listItem.setAttribute("aria-selected", "true");
        listItem.style.background = "rgba(255,255,255,0.10)";
        listItem.style.outline = "2px solid rgba(255,255,255,0.28)";
        listItem.style.boxShadow = "0 10px 22px rgba(0,0,0,0.18)";
        listItem.style.borderLeft = `6px solid ${color}`;
        const selectedIcon = document.createElement("span");
        selectedIcon.textContent = "✓";
        selectedIcon.setAttribute("aria-hidden", "true");
        selectedIcon.style.position = "absolute";
        selectedIcon.style.right = "10px";
        selectedIcon.style.top = "50%";
        selectedIcon.style.transform = "translateY(-50%)";
        selectedIcon.style.width = "18px";
        selectedIcon.style.height = "18px";
        selectedIcon.style.borderRadius = "999px";
        selectedIcon.style.border = `2px solid ${color}`;
        selectedIcon.style.display = "flex";
        selectedIcon.style.alignItems = "center";
        selectedIcon.style.justifyContent = "center";
        selectedIcon.style.fontSize = "12px";
        selectedIcon.style.color = color;
        listItem.appendChild(selectedIcon);
      } else {
        listItem.setAttribute("aria-selected", "false");
      }
      fragment.appendChild(listItem);
    }
    this.menuList.appendChild(fragment);
    this.menuList.hidden = true;
    this.menuBtn?.setAttribute("aria-expanded", "false");
  }

  updateDeliveryUnit() {
    const unit = document.getElementById("delivery_price_unit");
    if (unit) unit.textContent = this.deliveryPriceType?.value === 'amount' ? '£ (GBP)' : '%';
  }

  renderCurrentNameAndDefaultRules(current) {
    if (this.deliveryTimeInput) this.deliveryTimeInput.value = current?.delivery_time_days ?? '';
    if (this.deliveryPriceInput) this.deliveryPriceInput.value = current?.delivery_price ?? '';
    if (this.deliveryPriceType) this.deliveryPriceType.value = current?.delivery_price_type ?? 'percentage';
    this.updateDeliveryUnit();
    const currentName = String(current?.name ?? "");
    if (this.nameInput) {
      this.nameInput.value = currentName;
    }
    if (!this.form) {
      return;
    }
    const isDefault = currentName === "Default";
    this.form.style.display = isDefault ? "none" : "grid";
  }

  renderParentSelect(variationsRaw, current, parent, product) {
    if (!this.parentSelect) {
      return;
    }
    const variations = Array.isArray(variationsRaw) ? variationsRaw : [];
    const currentSku = String(current?.sku ?? current?.SKU ?? "").trim();
    this.parentSelect.innerHTML = `
      <option value="" disabled selected>
        Select a parent
      </option>
    `;
    const fragment = document.createDocumentFragment();
    for (let index = 0; index < variations.length; index += 1) {
      const variation = variations[index] || {};
      const sku = String(variation?.SKU ?? variation?.sku ?? "").trim();
      if (!sku || sku === currentSku) {
        continue;
      }
      const name = String(variation?.name ?? "(unnamed variation)");
      const option = document.createElement("option");
      option.value = sku;
      option.dataset.sku = sku;
      option.textContent = name;
      fragment.appendChild(option);
    }
    this.parentSelect.appendChild(fragment);
    const targetParent = String(parent?.sku ?? parent?.SKU ?? "") || String(product?.product_sku ?? "");
    const wanted = targetParent.trim().toUpperCase();
    if (!wanted) {
      return;
    }
    for (const option of this.parentSelect.options) {
      const value = String(option.value || "").trim().toUpperCase();
      const dataSku = String(option.dataset?.sku || "").trim().toUpperCase();
      if (value === wanted || dataSku === wanted) {
        option.selected = true;
        this.parentSelect.value = option.value;
        break;
      }
    }
  }

  renderTypeVariationsSelect(typeVariationsRaw, selectedTypeId) {
    if (!this.typeSelect || !Array.isArray(typeVariationsRaw)) {
      return;
    }
    this.typeSelect.innerHTML = `
      <option value="" disabled selected>
        Select type variation
      </option>
    `;
    for (let index = 0; index < typeVariationsRaw.length; index += 1) {
      const type = typeVariationsRaw[index] || {};
      const typeId = String(type?.type_id ?? "").trim();
      const typeName = String(type?.type_name ?? "").trim();
      if (!typeId || !typeName) {
        continue;
      }
      const option = document.createElement("option");
      option.value = typeId;
      option.id = `type_${typeId}`;
      option.textContent = typeName;
      this.typeSelect.appendChild(option);
    }
    const selected = selectedTypeId === null || selectedTypeId === undefined ? "" : String(selectedTypeId).trim();
    this.typeSelect.value = selected || "";
    if (selected && this.typeSelect.value !== selected) {
      this.typeSelect.value = "";
    }
  }

  renderServerPreviews(current) {
    const toAssetUrl = path => {
      const raw = String(path ?? "").trim();
      if (!raw) {
        return "";
      }
      if (raw.startsWith("http") || raw.startsWith("data:") || raw.startsWith("blob:")) {
        return raw;
      }
      const relativePath = raw.replace(/^\/+/, "");
      if (relativePath.startsWith("controller/")) {
        return "../../" + relativePath;
      }
      return "../../controller/" + relativePath;
    };

    // Image.
    if (this.imgPreview) {
      const serverImage = String(current?.image ?? "").trim();
      const imageSource = serverImage ? toAssetUrl(serverImage) || "../../view/variations/images/add_image.png" : "../../view/variations/images/add_image.png";
      this.imgPreview.innerHTML = "";
      const image = document.createElement("img");
      image.alt = "Selected variation image preview";
      image.loading = "lazy";
      image.decoding = "async";
      image.src = imageSource;
      this.imgPreview.appendChild(image);
    }

    // PDF name.
    if (this.namePdfInput) {
      this.namePdfInput.value = String(current?.name_pdf_artwork ?? "");
    }
    if (!this.pdfPreview) {
      return;
    }
    const serverPdf = String(current?.pdf_artwork ?? "").trim();
    if (!serverPdf) {
      this.pdfPreview.innerHTML = "";
      return;
    }
    const pdfName = String(current?.name_pdf_artwork ?? "").trim();
    const displayName = pdfName || serverPdf.split("/").pop() || "artwork.pdf";
    const downloadName = displayName.toLowerCase().endsWith(".pdf") ? displayName : `${displayName}.pdf`;
    const href = toAssetUrl(serverPdf);
    const pill = document.createElement("div");
    pill.className = "cp-file-pill";
    const openLink = document.createElement("a");
    openLink.href = href;
    openLink.target = "_blank";
    openLink.rel = "noopener noreferrer";
    openLink.className = "cp-file-pill-main";
    openLink.textContent = displayName;
    openLink.style.color = "var(--brand)";
    openLink.style.textDecoration = "none";
    const downloadLink = document.createElement("a");
    downloadLink.href = href;
    downloadLink.download = downloadName;
    downloadLink.textContent = "↓ Download";
    downloadLink.style.marginLeft = "8px";
    downloadLink.style.fontSize = "0.85em";
    downloadLink.style.color = "var(--muted)";
    pill.appendChild(openLink);
    pill.appendChild(downloadLink);
    this.pdfPreview.innerHTML = "";
    this.pdfPreview.appendChild(pill);
  }

  /* =========================
     Save variation
  ========================= */

  async saveVariationDetails(goNext = true) {
    const {
      skuProduct,
      skuVariation
    } = this.readSkuParamsFromUrl();
    let skuParentVariation = "";
    const selectedParent = this.parentSelect?.selectedOptions?.[0];
    if (selectedParent) {
      skuParentVariation = String(selectedParent.dataset?.sku || selectedParent.value || "").trim();
    }
    const typeId = String(this.typeSelect?.value || "").trim();
    const imageFile = this.imgInput?.files?.[0] || null;
    const pdfFile = this.pdfInput?.files?.[0] || null;
    if (imageFile && !imageFile.type.startsWith("image/")) {
      alert("The selected image file is not valid.");
      return false;
    }
    if (pdfFile && !this.isValidPdf(pdfFile)) {
      alert("Please select a valid PDF file.");
      return false;
    }
    if (this.deliveryPriceInput && !this.deliveryPriceInput.reportValidity()) return false;
    if (this.deliveryTimeInput && !this.deliveryTimeInput.reportValidity()) return false;
    const formData = new FormData();
    formData.append("delivery_time_days", this.deliveryTimeInput?.value ?? "");
    formData.append("delivery_price", this.deliveryPriceInput?.value ?? '');
    formData.append("delivery_price_type", this.deliveryPriceType?.value ?? 'percentage');
    formData.append("action", "save_variation_details");
    formData.append("sku_product", skuProduct);
    formData.append("sku_variation", skuVariation);
    formData.append("isAttachAnImage", imageFile ? "1" : "0");
    formData.append("isAttachAPDF", pdfFile ? "1" : "0");
    formData.append("name", String(this.nameInput?.value || "").trim());
    formData.append("name_pdf_artwork", String(this.namePdfInput?.value || "").trim());
    formData.append("type_id", typeId);
    if (skuParentVariation) {
      formData.append("sku_parent_variation", skuParentVariation);
    }
    if (imageFile) {
      formData.append("imageFile", imageFile);
    }
    if (pdfFile) {
      formData.append("pdfFile", pdfFile);
    }
    try {
      const response = await this.makeRequest("../../controller/products/variations.php", formData, {
        headers: {
          "X-Requested-With": "XMLHttpRequest"
        }
      });
      if (!response?.success) {
        console.error("Save failed:", response);
        alert(response?.message || "Could not save the variation.");
        return false;
      }
      window.headerAddProduct?.refreshSelection?.();
      if (goNext) {
        const destination = "../../view/images/index.php";
        if (window.headerAddProduct?.goNext) {
          window.headerAddProduct.goNext(destination);
        } else {
          window.location.href = destination;
        }
      }
      return true;
    } catch (error) {
      console.error("Save error:", error);
      alert(error.message || "Network/server error while saving.");
      return false;
    }
  }

  /* =========================
     Create variation
  ========================= */

  async addNewVariation() {
    const {
      skuProduct
    } = this.readSkuParamsFromUrl();
    if (!skuProduct) {
      alert("The product SKU was not found.");
      return;
    }
    try {
      const response = await this.makeRequest("../../controller/products/variations.php", {
        action: "create_new_variation",
        sku: skuProduct
      });
      if (!response?.success) {
        alert(response?.message || "The variation could not be created.");
        return;
      }
      const skuVariation = String(response.sku_variation || "").trim();
      if (!skuVariation) {
        return;
      }
      alert("The new variation has been successfully created. " + "Please fill in the details and save once you have finished.");
      window.location.href = "../../view/variations/index.php" + `?sku=${encodeURIComponent(skuProduct)}` + `&sku_variation=${encodeURIComponent(skuVariation)}`;
    } catch (error) {
      console.error("Create variation error:", error);
    }
  }

  /* =========================
     Helpers
  ========================= */

  readSkuParamsFromUrl() {
    const parameters = new URLSearchParams(window.location.search);
    return {
      skuProduct: parameters.get("sku") || "",
      skuVariation: parameters.get("sku_variation") || ""
    };
  }

  isValidPdf(file) {
    if (!file) {
      return false;
    }
    return file.type === "application/pdf" || file.type === "application/x-pdf" || file.type === "application/acrobat" || file.type === "application/x-bzpdf" || file.name.toLowerCase().endsWith(".pdf");
  }

  handleImgInputChange() {
    const file = this.imgInput.files?.[0];
    this.imgPreview.innerHTML = "";
    if (!file) {
      this.attachImage = false;
      return;
    }
    if (!file.type.startsWith("image/")) {
      alert("The selected image file is not valid.");
      this.imgInput.value = "";
      this.attachImage = false;
      return;
    }
    this.attachImage = true;
    if (this.currentImageObjectUrl) {
      URL.revokeObjectURL(this.currentImageObjectUrl);
      this.currentImageObjectUrl = null;
    }
    const imageUrl = URL.createObjectURL(file);
    this.currentImageObjectUrl = imageUrl;
    const image = document.createElement("img");
    image.src = imageUrl;
    image.alt = "Selected variation image preview";
    image.loading = "lazy";
    image.decoding = "async";
    this.imgPreview.appendChild(image);
  }

  handleClearImgBtnClick() {
    this.imgInput.value = "";
    this.imgPreview.innerHTML = "";
    this.attachImage = false;
    if (this.currentImageObjectUrl) {
      URL.revokeObjectURL(this.currentImageObjectUrl);
      this.currentImageObjectUrl = null;
    }
  }

  handlePdfInputChange() {
    const file = this.pdfInput.files?.[0];
    this.pdfPreview.innerHTML = "";
    if (!file) {
      this.attachPDF = false;
      return;
    }
    if (!this.isValidPdf(file)) {
      alert("Please select a valid PDF file.");
      this.pdfInput.value = "";
      this.attachPDF = false;
      return;
    }
    this.attachPDF = true;
    const pill = document.createElement("div");
    const name = document.createElement("span");
    const size = document.createElement("small");
    pill.className = "cp-file-pill";
    name.className = "cp-file-pill-main";
    name.textContent = file.name;
    size.textContent = `(${Math.round(file.size / 1024)} KB)`;
    pill.appendChild(name);
    pill.appendChild(size);
    this.pdfPreview.appendChild(pill);
  }

  handleClearPdfBtnClick() {
    this.pdfInput.value = "";
    this.pdfPreview.innerHTML = "";
    this.attachPDF = false;
  }

  handleMenuBtnClick(event) {
    event.stopPropagation();
    const willOpen = this.menuList.hidden;
    this.menuList.hidden = !willOpen;
    this.menuBtn.setAttribute("aria-expanded", String(willOpen));
  }

  handleDocumentClick(event) {
    const clickedButton = this.menuBtn.contains(event.target);
    const clickedMenu = this.menuList.contains(event.target);
    if (!clickedButton && !clickedMenu) {
      this.menuList.hidden = true;
      this.menuBtn.setAttribute("aria-expanded", "false");
    }
  }

  handleMenuListClick(event) {
    const listItem = event.target.closest("li");
    if (!listItem || !this.menuList.contains(listItem)) {
      return;
    }
    this.menuList.querySelectorAll(".is-selected").forEach(item => {
      item.classList.remove("is-selected");
    });
    listItem.classList.add("is-selected");
    const skuVariation = String(listItem.dataset?.sku || "").trim();
    if (!skuVariation) {
      return;
    }
    this.menuList.hidden = true;
    this.menuBtn.setAttribute("aria-expanded", "false");
    const {
      skuProduct
    } = this.readSkuParamsFromUrl();
    window.location.href = "../../view/variations/index.php" + `?sku=${encodeURIComponent(skuProduct)}` + `&sku_variation=${encodeURIComponent(skuVariation)}`;
  }

  handleDocumentKeydown(event) {
    if (event.key === "Escape" && !this.menuList.hidden) {
      this.menuList.hidden = true;
      this.menuBtn.setAttribute("aria-expanded", "false");
      this.menuBtn.focus();
    }
  }

  handleBackBtnClick() {
    const destination = "../../view/product_details/index.php";
    if (window.headerAddProduct?.goNext) {
      window.headerAddProduct.goNext(destination);
      return;
    }
    window.location.href = destination;
  }

  handleResetBtnClick(event) {
    event.preventDefault();
    alert("(pending implementation).");
  }

  handleNextBtnClick() {
    const name = String(this.nameInput?.value || "").trim();
    if (!name) {
      alert("Please add a name to the variation.");
      this.nameInput?.focus();
      return;
    }
    this.saveVariationDetails(true);
  }

  async handleSaveBtnClick() {
    const name = String(this.nameInput?.value || "").trim();
    if (!name) {
      alert("Please add a name to the variation.");
      this.nameInput?.focus();
      return;
    }
    const wasSaved = await this.saveVariationDetails(false);
    if (wasSaved) {
      await this.getDefaultVariation();
    }
  }

  async makeRequest(url, data, options = {}) {
    const {
      requireSuccess = false,
      responseType = "json",
      ...requestOptions
    } = options;
    const isFormData = data instanceof FormData;
    const headers = new Headers(requestOptions.headers || {});
    if (!isFormData && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
    const response = await fetch(url, {
      method: "POST",
      credentials: "same-origin",
      ...requestOptions,
      headers,
      body: isFormData ? data : JSON.stringify(data)
    });
    const text = await response.text();
    let result;
    try {
      result = responseType === "text" ? text : JSON.parse(text);
    } catch {
      const error = new Error("The server returned an invalid response.");
      error.status = response.status;
      throw error;
    }
    if (!response.ok || requireSuccess && !result?.success) {
      const error = new Error(result?.error || result?.message || "The request could not be completed.");
      error.status = response.status;
      error.code = result?.code || null;
      error.details = result;
      throw error;
    }
    return result;
  }
}

// Create one instance.
new Variations();
